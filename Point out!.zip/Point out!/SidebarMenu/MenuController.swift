//
//  MenuController.swift
//  Point Out! I'm in trouble.
//
//  Created by MKS on 14/9/16.
//  Copyright (c) 2016 MKS. All rights reserved.
//

import UIKit

class MenuController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
   
}
